from flask import Flask,render_template,url_for,request
import pickle
import joblib
import numpy as np

app=Flask(__name__)

model_path = './Trained_Model/model.pkl'
model = joblib.load(
    open(model_path, 'rb'))

@app.route('/')

def home():
    return render_template('index.html')

@app.route('/result',methods=['POST'])
def predict():
    # Getting the data from the form
    No_Of_Abuse_Report = int(request.form['No_Of_Abuse_Report'])
    No_Of_Rejected_Friend_Requests = int(request.form['No_Of_Rejected_Friend_Requests'])
    No_Of_Freind_Requests_Thar_Are_Not_Accepted = int(request.form['No_Of_Freind_Requests_Thar_Are_Not_Accepted'])
    No_Of_Friends = int(request.form['No_Of_Friends'])
    No_Of_Followers = int(request.form['No_Of_Followers'])
    No_Of_Likes_To_Unknown_Account = int(request.form['No_Of_Likes_To_Unknown_Account'])
    

    #query = np.array([[ApplicantIncome,CoapplicantIncome,LoanAmount,Credit_History,Property_Area]])
    query=np.array([No_Of_Abuse_Report, No_Of_Rejected_Friend_Requests,No_Of_Freind_Requests_Thar_Are_Not_Accepted, No_Of_Friends,No_Of_Followers, No_Of_Likes_To_Unknown_Account])
    prediction = model.predict([query])
    print(prediction)

    
    return render_template('result.html', prediction=prediction)


if __name__ == '__main__':
    app.run(debug=True)
